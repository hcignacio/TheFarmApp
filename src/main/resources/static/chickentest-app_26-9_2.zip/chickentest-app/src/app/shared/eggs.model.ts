export class Eggs {
    chickenId: number;
    creationDate: Date;
}