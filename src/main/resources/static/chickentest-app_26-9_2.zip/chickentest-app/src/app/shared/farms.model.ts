export class Farms {
    name: string;
    creationDate: Date;
}