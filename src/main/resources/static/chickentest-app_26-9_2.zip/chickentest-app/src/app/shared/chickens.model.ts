export class Chickens {
    name: string;
    farmId: number;
    joinDate: Date;
    //inFarm: boolean
    eggsAmount: number;
}