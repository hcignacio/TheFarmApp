export class Employees {
    id: number;
    name: string;
    email: string;
    phone: string;
}